
<?php $__env->startSection('section'); ?>
<br>
<h1>Personal Data's</h1>
	<form action="" method="POST">
		<label>Date: </label><input type="text" name="date" ><br>
				<label>Folder Number: </label><input type="text" name="fold_no"><br>
				<label>Fullname: </label><input type="text" name="name"><br>
				<label>Age: </label><input type="text" name="age"><br>
				<label>Prescription: </label><input type="text" name="pres_cc"><br>
				<label>Rx: </label><input type="text" name="rx"><br>

				<input type="submit" name="btnadd" value="Add">
<?php
	
	$connect= mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connect,'dbCheck-up');



?>
	</form>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jewel Joyce Ramos\Desktop\center\resources\views/addData.blade.php ENDPATH**/ ?>