
<?php $__env->startSection('section'); ?>
<form action="" method="POST">
	<div class="search">
		<label>Search Folder Number</label><input type="text" name="fold_no" placeholder="Search Folder Number">
		<br>
		<input type="submit" name="btnsearch" value="search" class="btn">
	</div>
		<br>
	</form>
<?php $__env->stopSection(); ?>		
<?php echo $__env->make('.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jewel Joyce Ramos\Desktop\center\resources\views/CheckUp.blade.php ENDPATH**/ ?>