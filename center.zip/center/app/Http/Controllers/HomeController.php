<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function addData(Request $request){
        //initialization
        $datee=$request->input('datee');
        $fold_no=$request->input('fold_no');
        $name=$request->input('name');
        $age=$request->input('age');
        $pres_cc=$request->input('pres_cc');
        $rx=$request->input('rx');
                //mysql insert command
        DB::INSERT("INSERT into tblcheck_up(datee,fold_no,name,age,pres_cc,rx)VALUES(?,?,?,?,?,?)", [$datee,$fold_no,$name,$age,$pres_cc,$rx]);
        return view('CheckUp',['patient' => $patient]);

    }
    public function CheckUp(Request $request){
     $patient = DB::SELECT("SELECT * FROM tblcheck_up");
        return view('CheckUp',['patient' => $patient]);   
    }
}
