@extends('.master')
@section('section')
<form action="" method="POST">
	<div class="search">
		<label>Search Folder Number</label><input type="text" name="fold_no" placeholder="Search Folder Number">
		<br>
		<input type="submit" name="btnsearch" value="search" class="btn">
	</div>
		<br>
	</form>
@endsection		